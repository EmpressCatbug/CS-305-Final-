package com.snhu.sslserver.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;

@RestController
public class ChecksumController {

    @GetMapping("/checksum")
    public String calculateChecksum() {
        String uniqueIdentifier = "Takeria Thompson - " + System.currentTimeMillis();
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(uniqueIdentifier.getBytes());
            String checksum = HexFormat.of().formatHex(hash);

            // Return a formatted string with line breaks for readability
            return "Data: " + uniqueIdentifier + "\n\n" +
                    "Name of Cipher Algorithm Used: SHA-256\n\n" +
                    "Checksum Value: " + checksum;
        } catch (NoSuchAlgorithmException e) {
            return "Error: SHA-256 algorithm not found";
        }
    }
}
